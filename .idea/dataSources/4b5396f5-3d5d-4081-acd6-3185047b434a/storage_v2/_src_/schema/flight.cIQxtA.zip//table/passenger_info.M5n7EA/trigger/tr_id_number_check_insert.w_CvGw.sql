create definer = root@localhost trigger TR_id_number_check_insert
    before insert
    on passenger_info
    for each row
BEGIN
DECLARE msg varchar(100);
IF CHAR_LENGTH(NEW.passenger_id_number) != 18 THEN
		SET msg = CONCAT('您输入身份证不符合：',NEW.passenger_id_number,' -请输入正确的身份证.');
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = msg;
	END IF;
END;

