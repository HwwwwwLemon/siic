create definer = root@localhost trigger TR_auto_extras_id
    before insert
    on extras
    for each row
BEGIN
-- 	
-- 	IF(new.grades = '商务舱') THEN
-- 		SET new.extras_id = CONCAT(date_format(now(),'%Y'),'-',new.flight_id,'-1');
-- 	ELSEIF(new.grades = '头等舱') THEN
-- 		SET new.extras_id = CONCAT(date_format(now(),'%Y'),'-',new.flight_id,'-2');
-- 	ELSEIF(new.grades = '经济舱') THEN
-- 		SET new.extras_id = CONCAT(date_format(now(),'%Y'),'-',new.flight_id,'-3');
-- 	END IF;
END;

