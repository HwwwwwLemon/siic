create definer = root@localhost trigger TR_update_flight_id
    before update
    on flight_info
    for each row
BEGIN
DECLARE nid varchar(30); 
DECLARE temp varchar(30);
	SELECT SUBSTR(flight_info.id,1,8) INTO temp FROM flight_info WHERE flight_id = old.flight_id;
	SET new.id = CONCAT(temp,new.flight_id);
END;

