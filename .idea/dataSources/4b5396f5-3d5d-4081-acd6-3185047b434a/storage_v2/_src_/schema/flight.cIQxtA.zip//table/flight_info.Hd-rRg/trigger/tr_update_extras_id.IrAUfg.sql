create definer = root@localhost trigger TR_update_extras_id
    before update
    on flight_info
    for each row
BEGIN
DECLARE id varchar(30); 
DECLARE oid varchar(30); 
DECLARE temp varchar(30);
	SET oid = old.flight_id;
	SET id = new.flight_id;
	SELECT SUBSTR(extras_id,1,5) INTO temp FROM extras WHERE flight_id = old.flight_id AND grades = '经济舱';
	
	UPDATE extras SET extras_id = CONCAT(temp,id,'-1') WHERE grades = '商务舱' AND flight_id = oid;
	UPDATE extras SET extras_id = CONCAT(temp,id,'-2') WHERE grades = '头等舱' AND flight_id = oid;
	UPDATE extras SET extras_id = CONCAT(temp,id,'-3') WHERE grades = '经济舱' AND flight_id = oid;
END;

