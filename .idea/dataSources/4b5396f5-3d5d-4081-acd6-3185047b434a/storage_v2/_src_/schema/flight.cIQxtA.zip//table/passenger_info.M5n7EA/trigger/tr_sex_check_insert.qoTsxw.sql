create definer = root@localhost trigger TR_sex_check_insert
    before insert
    on passenger_info
    for each row
BEGIN
DECLARE msg varchar(100);
IF new.passenger_sex != '男' AND new.passenger_sex != '女' THEN
	
		SET msg = CONCAT('您输入性别不符合：',NEW.passenger_sex,' -请输入正确的性别.');
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = msg;
	END IF;
END;

