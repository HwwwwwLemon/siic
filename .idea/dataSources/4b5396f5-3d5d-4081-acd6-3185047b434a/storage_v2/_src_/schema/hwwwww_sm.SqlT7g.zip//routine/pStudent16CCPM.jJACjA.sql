create
    definer = root@localhost procedure pStudent16CCPM()
BEGIN
	SELECT stu.SNo,stu.SName,stu.SBir FROM student stu
	WHERE political = '党员' AND LEFT(stu.SNo,3) = '160';
END;

