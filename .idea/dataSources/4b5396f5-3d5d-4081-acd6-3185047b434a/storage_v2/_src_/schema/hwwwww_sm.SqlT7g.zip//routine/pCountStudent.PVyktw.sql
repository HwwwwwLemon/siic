create
    definer = root@localhost procedure pCountStudent(IN sex char(2), IN pol varchar(10), IN majr varchar(40),
                                                     OUT result int)
BEGIN
	SELECT count(*) INTO result
	FROM student 
	WHERE ssex = sex AND major = majr AND political = pol;
	
END;

