create view v_course_72ctime as
select `hwwwww_sm`.`course`.`CNo`      AS `CNO`,
       `hwwwww_sm`.`course`.`CName`    AS `CNAME`,
       `hwwwww_sm`.`course`.`CTime`    AS `CTIME`,
       `hwwwww_sm`.`course`.`CCredits` AS `CCREDITS`
from `hwwwww_sm`.`course`
where (`hwwwww_sm`.`course`.`CTime` = '72');

