create
    definer = root@localhost procedure pSearchScore60_90_MAN(IN a varchar(30))
BEGIN
	SELECT stu.sno,sname,ssex,cname,score 
	FROM student stu,course cou,sc 
	WHERE stu.sno = sc.sno 
		AND cou.cno = sc.cno 
		AND ssex = '男' 
		AND cname = a 
		AND score BETWEEN 60 
		AND 90;
END;

