create
    definer = root@localhost function fgetAvgScore_Hwwwww(No char(10)) returns decimal
BEGIN
	DECLARE AvgScore DECIMAL;
	SET AvgScore = (SELECT AVG(Score) FROM sc WHERE sc.CNo = No);
	RETURN AvgScore;
END;

