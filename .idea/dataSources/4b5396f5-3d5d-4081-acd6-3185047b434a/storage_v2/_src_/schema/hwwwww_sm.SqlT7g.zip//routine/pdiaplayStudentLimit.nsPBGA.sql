create
    definer = root@localhost procedure pdiaplayStudentLimit(IN MaxCount int)
BEGIN
	DECLARE pSNo CHAR (10); #学生学号
	DECLARE pSName VARCHAR (10);#学生姓名
	DECLARE StudentNumber INT;#统计全校人数
	DECLARE ERR VARCHAR(100) DEFAULT '注意界限'; #错误信息
	DECLARE flag INT DEFAULT 0; #计数器
	DECLARE found boolean DEFAULT TRUE; #查找判断
	DECLARE cur_SNo CURSOR FOR SELECT SNo,SName FROM student ORDER BY SNo; #定义游标
	DECLARE exit HANDLER FOR NOT found CLOSE cur_SNo; #游标异常处理
	SELECT COUNT(*) INTO StudentNumber FROM student; #统计全校人数
	#查询界限限制
	IF MaxCount <= 0 OR  MaxCount > StudentNumber THEN
		SELECT GROUP_CONCAT(ERR,'  MAX:',StudentNumber,'人') 'ERR';
		SET found = FALSE; 
	END IF;
	
	OPEN cur_SNo;#打开游标
	#循环次数以及found控制循环次数
	WHILE found AND flag < MaxCount DO
		FETCH next FROM cur_SNo INTO pSNo,pSName; #将游标的值赋予pSNo,pSName
		SET flag = flag + 1; #计数器
		SELECT pSNo '学号',pSName '姓名'; #Display
	END WHILE;
	CLOSE cur_SNo;#关闭游标
END;

