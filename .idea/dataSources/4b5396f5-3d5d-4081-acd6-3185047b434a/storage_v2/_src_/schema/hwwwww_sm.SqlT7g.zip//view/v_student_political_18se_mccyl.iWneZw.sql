create view v_student_political_18se_mccyl as
select `hwwwww_sm`.`student`.`SNo`       AS `SNo`,
       `hwwwww_sm`.`student`.`SName`     AS `SName`,
       `hwwwww_sm`.`student`.`SSex`      AS `SSex`,
       `hwwwww_sm`.`student`.`SBir`      AS `SBir`,
       `hwwwww_sm`.`student`.`Scredits`  AS `Scredits`,
       `hwwwww_sm`.`student`.`political` AS `political`,
       `hwwwww_sm`.`student`.`major`     AS `major`
from `hwwwww_sm`.`student`
where ((`hwwwww_sm`.`student`.`political` = '共青团员') and (left(`hwwwww_sm`.`student`.`SNo`, 3) = '180') and
       (`hwwwww_sm`.`student`.`major` = '软件工程'));

-- comment on column v_student_political_18se_mccyl.SNo not supported: 学号

-- comment on column v_student_political_18se_mccyl.SName not supported: 姓名

-- comment on column v_student_political_18se_mccyl.SBir not supported: 出生年月

-- comment on column v_student_political_18se_mccyl.Scredits not supported: 总学分

