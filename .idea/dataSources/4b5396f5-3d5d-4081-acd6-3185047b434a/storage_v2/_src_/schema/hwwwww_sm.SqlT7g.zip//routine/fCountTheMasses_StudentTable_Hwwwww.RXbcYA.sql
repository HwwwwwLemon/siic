create
    definer = root@localhost function fCountTheMasses_StudentTable_Hwwwww() returns int
    RETURN ( SELECT COUNT(SNO) FROM student WHERE LEFT(SNO,6) = '180447' AND major = '软件工程' AND political = '群众');

