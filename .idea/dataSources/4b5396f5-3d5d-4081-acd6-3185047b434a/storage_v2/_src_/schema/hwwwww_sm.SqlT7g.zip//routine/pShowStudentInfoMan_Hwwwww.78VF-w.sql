create
    definer = root@localhost procedure pShowStudentInfoMan_Hwwwww()
BEGIN
SELECT student.SNo,SName,SSex,Score
FROM student,sc
WHERE student.SNo = sc.SNo AND
	  SSex = '男';
END;

