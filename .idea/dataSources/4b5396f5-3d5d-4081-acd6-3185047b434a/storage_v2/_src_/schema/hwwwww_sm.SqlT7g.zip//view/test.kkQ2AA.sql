create view test as
select `hwwwww_sm`.`student`.`SNo`       AS `sno`,
       `hwwwww_sm`.`student`.`SName`     AS `sname`,
       `hwwwww_sm`.`student`.`political` AS `political`
from `hwwwww_sm`.`student`
where (`hwwwww_sm`.`student`.`political` = '团员');

-- comment on column test.sno not supported: 学号

-- comment on column test.sname not supported: 姓名

