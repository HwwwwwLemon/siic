create
    definer = root@localhost procedure pAvgScore(IN id char(5))
BEGIN
	SELECT cno,avg( score ) 
	FROM sc 
	WHERE cno = id;
	
END;

