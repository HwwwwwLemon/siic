create
    definer = root@localhost function fisEmptyStudent() returns varchar(100)
BEGIN
DECLARE countStu int;
SELECT COUNT(*) INTO countStu FROM student;
IF(countStu = 0) THEN RETURN '此表为空';
ELSE RETURN countStu;
END IF;
END;

