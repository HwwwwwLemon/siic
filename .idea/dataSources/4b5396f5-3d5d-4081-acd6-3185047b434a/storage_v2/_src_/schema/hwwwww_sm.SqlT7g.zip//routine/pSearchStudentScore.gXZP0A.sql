create
    definer = root@localhost procedure pSearchStudentScore(IN No char(8))
BEGIN
	SELECT stu.SNo,stu.SName,cou.CNo,cou.CName,Score FROM student stu,course cou,sc
	WHERE stu.Sno = No AND sc.SNo = No AND sc.CNo = cou.CNo;
END;

