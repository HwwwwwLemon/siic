create view v_student_course_18se7 as
select `stu`.`SNo`                  AS `SNo`,
       `stu`.`SName`                AS `SName`,
       `hwwwww_sm`.`sc`.`CNo`       AS `CNo`,
       `hwwwww_sm`.`course`.`CName` AS `CName`
from ((`hwwwww_sm`.`student` `stu` join `hwwwww_sm`.`course`)
         join `hwwwww_sm`.`sc`)
where ((`stu`.`SNo` = `hwwwww_sm`.`sc`.`SNo`) and (`hwwwww_sm`.`course`.`CNo` = `hwwwww_sm`.`sc`.`CNo`) and
       (left(`stu`.`SNo`, 6) = '180447'))
order by `stu`.`SNo`;

-- comment on column v_student_course_18se7.SNo not supported: 学号

-- comment on column v_student_course_18se7.SName not supported: 姓名

