create view v_student_course_17cn1 as
select `stu`.`SNo`                                                                           AS `SNo`,
       `stu`.`SName`                                                                         AS `SName`,
       group_concat(`hwwwww_sm`.`sc`.`CNo`, '-', `hwwwww_sm`.`course`.`CName` separator ',') AS `选课情况`
from ((`hwwwww_sm`.`student` `stu` join `hwwwww_sm`.`course`)
         join `hwwwww_sm`.`sc`)
where ((`stu`.`SNo` = `hwwwww_sm`.`sc`.`SNo`) and (`hwwwww_sm`.`course`.`CNo` = `hwwwww_sm`.`sc`.`CNo`) and
       (left(`stu`.`SNo`, 6) = '170111'))
group by `stu`.`SNo`;

-- comment on column v_student_course_17cn1.SNo not supported: 学号

-- comment on column v_student_course_17cn1.SName not supported: 姓名

