create
    definer = root@localhost function fgetMaxScoreCount_Hwwwww(No char(10), Score decimal) returns int
BEGIN
	DECLARE i INT;
	SET i = (SELECT count(*) FROM sc WHERE sc.CNo = No AND sc.Score = Score);
	RETURN i;
END;

