create
    definer = root@localhost procedure pShowStudentInfo_Hwwwww()
BEGIN
SELECT SNo,SName,SSex,Scredits
FROM student
WHERE YEAR(SBir) = '1998' AND
      LEFT(SNo,6) = '180447';
END;

