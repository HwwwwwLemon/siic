create
    definer = root@localhost procedure pisEmpty(IN tableName varchar(20))
BEGIN
set @tableName = CONCAT(tableName);
set @sqlStr = CONCAT('SELECT COUNT(*) FROM ', @tableName);
prepare stmt from @sqlStr;
execute stmt;
deallocate prepare stmt;
END;

