create
    definer = root@localhost function fgetStudentName_Hwwwww(No char(10)) returns varchar(20)
BEGIN
	DECLARE Name VARCHAR(20);
	SET Name = (SELECT SName FROM student WHERE student.SNo = No);
	RETURN Name;
END;

