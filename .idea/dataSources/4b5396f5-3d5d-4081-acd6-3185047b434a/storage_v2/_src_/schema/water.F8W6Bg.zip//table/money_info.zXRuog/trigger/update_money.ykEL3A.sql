create definer = root@localhost trigger update_money
    after update
    on money_info
    for each row
BEGIN
	DECLARE temp1 DECIMAL(10,2);
	DECLARE temp2 DECIMAL(10,2);
	DECLARE temp3 VARCHAR(30);
	SET temp3 = new.user_id;
	SELECT money INTO temp1 FROM money_info WHERE  money_info.user_id = temp3 AND type = 1;
	SELECT money INTO temp2 FROM money_info WHERE money_info.user_id = temp3 AND type = 2;
	UPDATE user_info SET user_info.money = temp2-temp1 WHERE user_info.id = temp3;
END;

