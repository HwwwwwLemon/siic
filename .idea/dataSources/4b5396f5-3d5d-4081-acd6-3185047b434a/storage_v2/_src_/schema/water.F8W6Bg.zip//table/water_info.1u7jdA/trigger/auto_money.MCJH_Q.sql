create definer = root@localhost trigger auto_money
    before insert
    on water_info
    for each row
BEGIN
	DECLARE temp DECIMAL(10,2);
	DECLARE temp2 DECIMAL(10,2);
	SELECT price INTO temp2 FROM water_type_info,user_info WHERE user_info.id = new.user_id AND water_type_info.type = user_info.water_type;
	SET new.total_price = temp2 * new.water_consumption;
END;

