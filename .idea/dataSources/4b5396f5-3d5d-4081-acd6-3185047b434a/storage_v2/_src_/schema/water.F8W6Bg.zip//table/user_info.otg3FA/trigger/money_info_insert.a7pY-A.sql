create definer = root@localhost trigger money_info_insert
    before insert
    on user_info
    for each row
BEGIN
	INSERT INTO money_info (money_info.user_id,money_info.type,money) VALUES (new.id,1,0),(new.id,2,0);
END;

