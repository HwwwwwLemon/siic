create definer = root@localhost trigger money_cal_pay
    before insert
    on pay_info
    for each row
BEGIN
	DECLARE temp DECIMAL(10,2);

	SELECT SUM(payment_amount) INTO temp FROM pay_info WHERE user_id = new.user_id;
	IF(temp IS NULL) THEN SET temp = 0; END IF;
	UPDATE money_info SET money = temp + new.payment_amount WHERE money_info.user_id = new.user_id AND money_info.type = 2;
END;

