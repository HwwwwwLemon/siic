create definer = root@localhost trigger money_cal_water
    after insert
    on water_info
    for each row
BEGIN
	DECLARE temp DECIMAL(10,2);
	SELECT SUM(total_price)+new.total_price INTO temp FROM water_info WHERE user_id = new.user_id;
	UPDATE money_info SET money = temp WHERE user_id = new.user_id AND money_info.type = 1;
END;

